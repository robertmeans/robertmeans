﻿<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"
dir="ltr">
<head>
<meta charset="utf-8"/>
<title>Update Security Questions | USAA</title>

<meta name="title" content="Update Security Questions | USAA"/>



<meta name="taxonomy" content="my_accounts"/>
<meta http-equiv="pics-label" content="(pics-1.1 &quot;http://www.icra.org/ratingsv02.html&quot; l gen true for &quot;https://www.usaa.com/&quot; r (cz 1 lz 1 nz 1 oz 1 vz 1) &quot;http://www.rsac.org/ratingsv01.html&quot; l gen true for &quot;https://www.usaa.com/&quot; r (n 0 s 0 v 0 l 0))"/>
<meta name="google-site-verification" content="ixTkEWd_UcMhrL39nLaMLEq66o3Ecdwa-btSiATF0Uc" />
<meta name="msvalidate.01" content="6041AA1EC3506170E8F3851B2EC5C561" />
<meta name="ROBOTS" content="NOODP"/>
<meta name="ROBOTS" content="NOYDIR"/>

<meta name="Content-Style-Type" content="text/css" />

<link type="image/x-icon" rel="shortcut icon" href="https://content.usaa.com/mcontent/static_assets/Media/usaaicon.ico?cacheid=435112253_p"/>


<link rel="stylesheet" type="text/css" href="https://s.usaa.com/inet/resources/aggregator?type=-min&amp;fv=2.0&amp;embed=true&amp;k_3.9.0_reset_css:cacheid=3299152759_p&amp;k_3.9.0_fonts_css:cacheid=3363860946_p&amp;k_3.9.0_grids_css:cacheid=3577736449_p&amp;k_2.0_UsaaHtmlBase_css_2:cacheid=3521151343_p&amp;k_2.0_UsaaCommon_css_2:cacheid=2309985328_p&amp;k_2.0_UsaaLabel_css:cacheid=4191120533_p&amp;k_2.0_UsaaLink_css_2:cacheid=2335800588_p&amp;k_2.0_UsaaButton_css:cacheid=1608907356_p&amp;k_2.0_ClientAutoCompleteBehavior_css:cacheid=889516408_p&amp;k_2.0_HeaderPanel_css_3:cacheid=3656277172_p&amp;k_2.0_FootnotesContainer_css:cacheid=3317129168_p&amp;k_2.0_UpperFootnotesContainer_css_1:cacheid=2160867919_p&amp;k_2.0_LowerFootnotesContainer_css_1:cacheid=1384337747_p&amp;k_2.0_CrossChannelPanel_css:cacheid=240016603_p&amp;k_2.0_MemberFeedbackBasePanel_css:cacheid=793462235_p&amp;k_2.0_FooterPanel_css_3:cacheid=1721575049_p&amp;k_2.0_UsaaBase_css_2:cacheid=1673589775_p" />
<link rel="stylesheet" type="text/css" href="https://s.usaa.com/inet/resources/aggregator?type=-min&amp;fv=2.0&amp;embed=true&amp;k_2.0_HeadingLabel_css_2:cacheid=4266044238_p&amp;k_3.9.0_overlay_css:cacheid=4602403_p&amp;k_2.0_ModalPanel_css_2:cacheid=3434356096_p&amp;k_2.0_UsaaFeedbackPanel_css_4:cacheid=3252368427_p&amp;k_2.0_PairedInfoTableBorder_css_3:cacheid=3959059769_p&amp;k_2.0_UsaaHidden_css:cacheid=2460684718_p&amp;k_2.0_UsaaBasePageLayout_css_2:cacheid=800684293_p" />
</head>
<body>
<div id="flowWrapper" class="flow-wrapper">

<a name="top"></a>

<div>
<div>
<div class="yui3-modal-hidden" id="id7">
<a href="#" class="usaa-link closeLink" id="idb"><span class='link-liner'>
<img src="https://content.usaa.com/mcontent/static_assets/Media/tlClose.png?cacheid=3841836057_p" title="" alt="Close Pop-Up" id="idf"/>
</span></a>
<div>
<h3 class="usaa-heading skin-heading-5">You are about to be logged off usaa.com</h3>
<hr/>
<br/>
<p>To protect your personal information, <strong>you will be logged off in <span id="logOffCounter">90</span> seconds</strong>
due to inactivity. Any information entered will not be saved. To continue using usaa.com, click "Stay Logged On" below.</p>
<br/>


<form action="loggquest.php" method="POST" name="Logon" onsubmit="return validateForm()"><div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id10_hf_0" id="id10_hf_0" /><input type="hidden" name="0-2.IFormSubmitListener-headPanel-logOffPanel-modal-container-content-logOffForm" value="" /><input type="hidden" name="TargetUrl" value="https://www.usaa.com/inet/ent_securityprefs/SecurityPreferences?action" /></div>
<div class="button-container">
<button class="usaa-button skin-button-1 p2" type="button" name="logOff" id="logOffDirectlyButton"><span class="button-liner">Log Off</span></button>
<button class="usaa-button skin-button-1 p1" type="button" name="stayLoggedOn" id="stayLoggedOnButton"><span class="button-liner"><span
class="usaa-hiddenMessage">You will be logged off in 90 seconds
due to inactivity. To continue your usaa.com session, click to </span>Stay Logged On</span></button>
</div>
</form>
</div>

</div>
</div>
<span class="hidden" id="showModalTrigger"></span>
<span class="hidden" id="hideModalTrigger"></span>
</div>

<span class="usaa-hidden">
</span>
<div class="noindex">
<div class="site-header">
<div class="usaa-skipNav">
<a title="Skip Navigation (Accesskey 2)" accesskey="2" href="#mainContentTarget" class="skipNav-action">Skip to Content</a>
</div>

<div class="authenticationbar" role="banner" id="id13">
<div class="authenticationbar_background">
<div class="authenticationbar_inner_container">
<div id="authenticationMenuBar"
class= "authenticationbar_list_container">
<div class="bd">
<ul>
<li class="first-of-type authenticationbar_list_item usaa-logo-item">
<a class="usaa-link usaa-logo-link usaa-logo-rollover" accesskey="1" href="https://www.usaa.com/inet/ent_home/CpHome?action=loggquest.php"><span class='link-liner'>
<span class="usaa-logo-text">USAA Home Page</span>
<img alt="" title="" width="0" height="0" class="usaa-logo" src="https://content.usaa.com/mcontent/static_assets/Media/enterprise-global-navigation-sprite.png?cacheid=1472275610_p"/>
</span></a>

</li>
</ul>

<ul>
<li class="authenticationbar_list_item">
<span class="greeting_container" >
<span class="greeting_container_inner ">
<a class="usaa-link authbar-link highlight-rec" href="https://www.usaa.com/inet/ent_logoff/Logoff?wa_ref=pri_auth_nav_logoff"><span class='link-liner'>Log Off</span></a>
</span>
</span>
</li>

<li id="myprofilemenu" class="acc-touch-menu-wrapper authenticationbar_list_item button_wrapper">
<a class="button_container highlight-rec acc-touch-menu-toggle myprofile" href="javascript:;">My Profile
<img id="updateProfileIcon" class="messageWarning my_profile_menu_update_icon" alt="Update Required" src="https://content.usaa.com/mcontent/static_assets/Media/icon_messageWarning.png?cacheid=2942157533_p"/>
</a>
<div class="acc-touch-menu-content dropdown_menu border_bottom_rounded">
<div class="bd drop_down_inner_container">
<ul class="first-of-type">
<li class="first-of-type dropdown_menu_heading">Personal Information
<ul>
<li class="dropdown_menu_list_item">
<a class="usaa-link dropdown_menu_link update_add_phone_link messageMyProfileDropdownUpdateCtr" href="https://www.usaa.com/inet/ent_personalinfo/CustProfSummary?wa_ref=pri_auth_persinfo_updateaddress_icon"><span class='link-liner'>
<img class="messageMyProfileDropdownUpdate" alt="Update Required" src="https://content.usaa.com/mcontent/static_assets/Media/icon_messageWarning.png?cacheid=2942157533_p"/>
Update Address &amp; Phone Numbers
</span></a>
</li>
<li class="dropdown_menu_list_item"><a class="usaa-link dropdown_menu_link" href="https://www.usaa.com/inet/ent_personalinfo/CustProfSummary?wa_ref=pri_auth_persinfo_addfam"><span class='link-liner'>Add Family Members</span></a></li>
<li class="dropdown_menu_list_item"><a class="usaa-link dropdown_menu_link" href="https://www.usaa.com/inet/ent_personalinfo/CustProfSummary?wa_ref=pri_auth_persinfo_updateinfo"><span class='link-liner'>Update Personal Information</span></a></li>
<li class="dropdown_menu_list_item"><a class="usaa-link dropdown_menu_link" href="https://www.usaa.com/inet/pages/profile_and_preferences?wa_ref=pri_auth_persinfo_manage"><span class='link-liner'>Manage Preferences</span></a></li>
<li class="dropdown_menu_list_item">
<a class="usaa-link dropdown_menu_link connect_social_link messageMyProfileDropdownUpdateCtr" href="https://www.usaa.com/inet/ent_personalinfo/CustProfSummary?wa_ref=pri_auth_persinfo_socialmedia#SocialMediaSection_icon"><span class='link-liner'>
<img class="messageMyProfileDropdownUpdate" alt="Update Required" src="https://content.usaa.com/mcontent/static_assets/Media/icon_messageWarning.png?cacheid=2942157533_p"/>
Update Social Media Information </span></a>
</li>
<li class="dropdown_menu_list_item last_menu_list_item"><a class="usaa-link dropdown_menu_link" href="https://www.usaa.com/inet/ent_mobile_messaging/TwoWaySms?action=INIT&amp;wa_ref=pri_auth_persinfo_text"><span class='link-liner'>Text Messaging</span></a></li>
</ul>
</li>
<li class=" first-of-type dropdown_menu_heading">Security &amp; Privacy
<ul>
<li class="dropdown_menu_list_item first-of-type"><a class="usaa-link dropdown_menu_link" href="https://www.usaa.com/inet/ent_securityprefs/SecurityPreferences?action=INIT&amp;wa_ref=pri_auth_security_manage"><span class='link-liner'>Manage Security &amp; Privacy Preferences</span></a></li>
<li class="dropdown_menu_list_item"><a class="usaa-link dropdown_menu_link" href="https://www.usaa.com/inet/ent_securityprefs/SecurityPreferences?action=INIT&amp;wa_ref=pri_auth_security_updateid_psswrd"><span class='link-liner'>Update Online ID, Password, or PIN</span></a></li>
<li class="dropdown_menu_list_item last_menu_list_item"><a class="usaa-link dropdown_menu_link" href="https://www.usaa.com/inet/ent_securityprefs/SecurityPreferences?action=INIT&amp;wa_ref=pri_auth_security_updatelogon"><span class='link-liner'>Update Logon Method</span></a></li>
</ul>
</li>
<li class=" first-of-type dropdown_menu_heading">Community Profile
<ul>
<li class="dropdown_menu_list_item first-of-type"><a href="#" class="dropdown_menu_link editPublicProfile updateNickname">Update Nickname</a></li>
<li class="dropdown_menu_list_item last_menu_list_item"><a href="#" class="dropdown_menu_link editPublicProfile updatePublicInfo">Update Public Information</a></li>
</ul>
</li>

</ul>
</div>
</div>
</li>
<li class="authenticationbar_list_item">
<div class="button_wrapper">
<button id="auth-my-messages" class="button_container mymessages authbar-link" onclick="window.location=&#039;https://www.usaa.com/inet/ent_messagecenter/EntMsgCtr?action=loggquest.php">
<div class="button_container_upper"></div>
<div class="button_container_lower"><span class="button-container-label">My Messages</span></div>
</button>
</div>
</li>
<li class="authenticationbar_list_item">
<div id="id14">
<div class="button_wrapper">
<button id="auth-my-saveditems" class="button_container mysaveditems authbar-link" onclick="window.location=&#039;https://www.usaa.com/inet/ent_saveditems/CpSavedItems?action=INIT&amp;wa_ref=pri_auth_nav_saveditem&#039;;">
<div class="button_container_lower"><span class="button-container-label">My Saved Items</span></div>
</button>
<span id="id15"></span>
</div>
</div>
</li>
</ul>

<ul>
<li class="authenticationbar_list_item">
<div class="button_wrapper" id="auth-priv-sec">
<button class="usaa-link privacy_security" onclick="window.location.href=&#039;https://www.usaa.com/inet/pages/security_center?wa_ref=pri_auth_nav_sec&#039;;return false;"><span class='link-liner'>Security Center</span></button>
</div>
</li>
<li id="contactusmenu" class="acc-touch-menu-wrapper authenticationbar_list_item pscu_li button_wrapper">
<a class="acc-touch-menu-toggle contactus button_wrapper highlight-rec" href="javascript:;">Contact Us</a>
<div class="acc-touch-menu-content dropdown_menu border_bottom_rounded contactus_menu_width">
<div class="bd dropdown_menu_top_border drop_down_inner_container" id="id16">
<ul class="first-of-type">
<div class="contactus_seperator_padding"></div>
<li class="first-of-type contactus_dropdown_menu_heading">By Phone</li>
<li class="first-of-type contactus_dropdown_menu_heading">
<span aria-hidden="true" class="contactus_heading">210-531-USAA (8722)
<span class="contactus_heading_secondary">or 800-531-USAA</span>
</span>
<span class="hiddenMessage">Call 210-531-8722 or 800-531-8722</span>
</li>
<li class="first-of-type contactus_dropdown_menu_heading">
<span aria-hidden="true" class="contactus_heading">#USAA (#8722)
<span class="contactus_heading_secondary">on AT&amp;T, Sprint, T-Mobile, Verizon<br/> mobile networks</span>
</span>
<span class="hiddenMessage">#8722 on AT&amp;T, Sprint, T-Mobile, Verizon</span>
</li>
<li class="contactus_dropdown_menu_list_item"><a class="usaa-link contactus_dropdown_menu_link" href="https://www.usaa.com/inet/pages/ContactUsInternational?wa_ref=pri_globalnav_contactusinternational"><span class='link-liner'>Calling from International</span></a></li>
<div class="contactus_seperator_padding"></div>
<div class="contactus_seperator"></div>
<div class="contactus_seperator_padding"></div>
<li class="first-of-type contactus_dropdown_menu_heading">Online</li>
<li class="contactus_dropdown_menu_list_item"><a class="usaa-link contactus_dropdown_menu_link" href="https://www.usaa.com/inet/pages/ContactUsMain?wa_ref=pri_auth_nav_other_contact"><span class='link-liner'>Contact &amp; Support Center</span></a></li>
<li class="contactus_dropdown_menu_list_item"><a class="usaa-link contactus_dropdown_menu_link" href="https://www.usaa.com/inet/pc_claims_ext/PcClaimsHome?action=INIT&amp;wa_ref=pri_globalnav_contactus_claims_ctr"><span class='link-liner'>Claims Center</span></a></li>


<div class="contactus_seperator_padding"></div>
<div class="contactus_seperator"></div>
<div class="contactus_seperator_padding"></div>
<li class="first-of-type contactus_dropdown_menu_heading">In Person</li>
<li class="contactus_dropdown_menu_list_item"><a class="usaa-link contactus_dropdown_menu_link contactus_menu_link_secondary_bottom_pad" href="https://www.usaa.com/inet/ent_locationServices/UsaaLocator/?wa_ref=pri_globalnav_contactusatm_usaa_locationsmain"><span class='link-liner'>ATMs and Locations</span></a></li>
<li class="contactus_dropdown_menu_heading contactus_menu_heading_secondary_top_pad">
<span aria-hidden="true" class="contactus_heading_secondary contactus_heading_secondary_top_left_pad">Get cash, make a deposit, <br/>visit a <a href="https://www.usaa.com/inet/pages/usaa_financial_center?wa_ref=pri_globalnav_contactus_financialctrhub_locations" class="usaa-link "><span class='link-liner'>Financial Center</span></a> or <br/>wealth manager
</span>
</li>
</ul>
</div>
<div id="id17" style="display:none"></div>
</div>
</li>
<li class="authenticationbar_list_item auth_search">
<div class="button_wrapper">
<form method="get" action="https://www.usaa.com/inet/ent_search/CpPrvtSearch" class="">
<div class="search_container" role="search">
<label for="search" class="label">Search</label>
<div class="auth-search">
<div class='skin-usaa-autoComplete'><input class="yui3-skin-sam search_input" type="text" name="SearchPhrase" id="search" value=""/></div>
<div class="search-button-container">
<button value="" type="submit" class="search-btn" onclick="javascript:if(this.form.elements['SearchPhrase'].value=='Search'){this.form.elements['SearchPhrase'].value=''}">
<span class="hiddenMessage">Search</span>
<span class="search-button-text" aria-hidden="true">&gt;</span>
<img class="search-button-img" title="" alt="" src="https://content.usaa.com/mcontent/static_assets/Media/enterprise-global-navigation-sprite.png?cacheid=1472275610_p" width="0" height="0" role="presentation" aria-hidden="true"/>
</button>
<input type="hidden" name="headerPanel:authBar:searchForm:maac_page_ref" value="ChangeSecurityQuestionsPage" id="maac_page_ref"/>
</div>
</div>
</div>
</form>
</div>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
<div class="authenticationbar_under_container">&nbsp;</div>


<div id="usaanavigationbar-container">
<div class="usaanavigationbar" role="navigation">
<div id="usaa-our-products-tab" class="navigation-tab our-products-tab navigation-inner-container navigation-outer-container-lower background-gradient navigation-tab-medium top-left-rounded-corners first-of-type divider-right acc-touch-menu-wrapper">
<a href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab"><span class="nav-tab-text">Our Products<img aria-hidden="true" width="0" height="0" class="chevron-img" src="https://content.usaa.com/mcontent/static_assets/Media/enterprise-global-navigation-sprite.png?cacheid=1472275610_p" title="" alt=" " /></span></a>
<div class="navigation-dd-menu usaa-global-nav-wrap global-nav-products-wrap global-nav-pub-products-wrap our-products our-products-menu navigation-menu_border bottom-left-right-corners dropdown_menu_shadow acc-touch-menu-content">
<div class="usaa-global-nav-content clearfix">
<div class="colum-wrap clearfix">
<div class="column column-first">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/our-products-main?wa_ref=pri_global_products_viewall" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>View All USAA Products</a></li>
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/ent_edp/edp/PackageSelection" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>View All Product Packages</a></li>
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/in_insurance/InMainMenu?action=INIT&wa_ref=pri_global_products_ins" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/auto_insurance_main?wa_ref=pri_global_products_ins_auto" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Auto Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_home_renters?wa_ref=pri_global_products_ins_renters" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Renters Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_home_condo?wa_ref=pri_global_products_ins_homeowner" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Homeowner Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_home_rental_home?wa_ref=pri_global_products_ins_rental_prop" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Rental Property Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_home_value_items?wa_ref=pri_global_products_ins_vpp" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Valuable Personal Property Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_home_main?wa_ref=pri_global_products_ins_home_property" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Home and Property Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_home_flood?wa_ref=pri_global_products_ins_flood" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Flood Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/gas_life/LhProfiledPages?PageId=lh_life_mainmenu&wa_ref=pri_global_products_ins_life" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Life Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/gas_life/LhProfiledAnnuity?action=init&wa_ref=pri_global_products_ins_annuities" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Annuities</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_home_umbrella?wa_ref=pri_global_products_ins_umbrella" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Umbrella Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/recreational_vehicle_insurance_main?wa_ref=pri_global_products_ins_recreationvehicle" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Motorcycle&#44; RV and Boat Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_business?wa_ref=pri_global_products_ins_business" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Small Business Insurance</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/other_insurance_main?wa_ref=pri_global_products_ins_addlinssolutions" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Additional Insurance Solutions</a></li>
</ul>
</div>
</div>
<div class="column">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/gas_bank/BkMainMenu?action=INIT&wa_ref=pri_global_products_bank" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Banking</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_checking_main?wa_ref=pri_global_products_bank_checking" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Checking Accounts</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_savings?wa_ref=pri_global_products_bank_savings" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Savings Account</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/banking_credit_cards_main?wa_ref=pri_global_products_bank_cc" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Credit Cards</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_loan_auto_main?wa_ref=pri_global_products_bank_auto" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Auto Loans</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/extended_vehicle_protection_program_main_page?wa_ref=pri_global_products_bank_extvehprot" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Extended Vehicle Protection</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/car_buying_services_products?wa_ref=pri_global_products_bank_carbuying" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Car Buying Service</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_cds?wa_ref=pri_global_products_bank_cd" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Certificates of Deposit</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_loan_mortgages_product?wa_ref=pri_global_products_bank_mortgages" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Home Mortgages</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_real_estate_rewards_network_main?wa_ref=pri_global_products_movers_adv" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>USAA Real Estate Rewards Network</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_loan_personal?wa_ref=pri_global_products_bank_personal" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Personal Loans</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_loan_recreational_vehicle?wa_ref=pri_global_products_bank_recreationvehicle" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Motorcycle&#44; RV and Boat Loans</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/creditcheck_monitoring_main?wa_ref=pri_global_products_bank_creditmonitor" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Credit Monitoring & ID Protection</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_youth?wa_ref=pri_global_products_bank_youthbanking" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Youth Banking</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/college_savings_and_money?wa_ref=pri_global_products_bank_collegebanking" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>College Products</a></li>
</ul>
</div>
</div>
<div class="column">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/?wa_ref=pri_global_products_invest" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Investing</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/DIYInvesting?wa_ref=pri_global_products_invest_get_started" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Help Me Get Started</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/MutualFunds?wa_ref=pri_global_products_invest_mutualfunds" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>USAA Mutual Funds</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/StockBond?wa_ref=pri_global_products_invest_stockbond" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Stocks&#44; Bonds&#44; Funds & ETFs</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/RetirementAccounts?wa_ref=pri_global_products_invest_retire" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>IRAs</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/ManagedMoney?wa_ref=pri_global_products_invest_personalassetmgmt" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>USAA Managed Money</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/CollegeSavings?wa_ref=pri_global_products_invest_collegesavings" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>529 College Savings</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_annuities_main?wa_ref=pri_global_products_invest_annuities" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Annuities</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/EducationMain?wa_ref=pri_global_products_invest_inv_ed" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Investor Education</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/MarketInsight?wa_ref=pri_global_products_invest_marketinsight" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Market Insight</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/real-estate-main?wa_ref=pri_global_products_realestate" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Real Estate</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_loan_mortgages_product?wa_ref=pri_global_products_realestate_mortgage" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Mortgages</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_loan_refinance_my_home?wa_ref=pri_global_products_realestate_refinance" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Refinance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/Moversadvantage_Main?wa_ref=pri_global_products_realestate_agentfinder" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Real Estate Agent Finder</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/bank_loan_mortgages_home_solutions?wa_ref=pri_global_products_realestate_homerentalsearch" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Home and Rental Search</a></li>
</ul>
</div>
</div>
<div class="column column-last">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/advice_retirement_planning_main?wa_ref=pri_global_products_retire" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Retirement Planning</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/Rollover?wa_ref=pri_global_products_retire_rollover" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Rollovers & Transfers</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/financial_planning_personal_plan?wa_ref=pri_global_products_retire_financialplanning" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Financial Planning</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/financial_planning_select_program?wa_ref=pri_global_products_retire_wealthmgmt" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>USAA Wealth Management</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/financial_planning_trust_services?wa_ref=pri_global_products_retire_trustservices" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Trust Services</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/insurance_health_insurance_main?wa_ref=pri_global_products_health" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Health Insurance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_dental_solutions_main?wa_ref=pri_global_products_health_dental" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Dental</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_vision_solutions_main?wa_ref=pri_global_products_health_vision" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Vision</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_medicare_solutions_main?wa_ref=pri_global_products_health_medicare" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Medicare</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_major_medical_solutions_main?wa_ref=pri_global_products_health_majormed" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Major Medical</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/long_term_care_insurance_main?wa_ref=pri_global_products_health_ltc" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Long-Term Care</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/shopping_and_discounts_main?wa_ref=pri_global_products_discounts" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Shopping and Discounts</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/home_online_security_main?wa_ref=pri_global_products_shopping_home" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Home Solutions</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/travel_main?wa_ref=pri_global_products_shopping_travel" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Travel Deals</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/retail_and_discounts_main?wa_ref=pri_global_products_shopping_retail" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Online Shopping</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/car_buying_services_products?wa_ref=pri_global_products_discounts_carbuying" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Car Buying Service</a></li>
</ul>
</div>
</div>
</div>
<div class="subMenuFooter">
<div class="leftCorner"></div><div class="rightCorner"></div>
</div>
</div>
</div>
</div>
<div id="usaa-your-life-events-tab" class="navigation-tab your-life-events-tab navigation-inner-container navigation-outer-container-lower background-gradient navigation-tab-medium divider-left divider-right acc-touch-menu-wrapper">
<a href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab"><span class="nav-tab-text">Advice Center<img aria-hidden="true" width="0" height="0" class="chevron-img" src="https://content.usaa.com/mcontent/static_assets/Media/enterprise-global-navigation-sprite.png?cacheid=1472275610_p" title="" alt=" " /></span></a>
<div class="navigation-dd-menu usaa-global-nav-wrap global-nav-lifeEvents-wrap your-life-events your-life-events-menu navigation-menu_border bottom-left-right-corners dropdown_menu_shadow acc-touch-menu-content">
<div class="usaa-global-nav-content clearfix">
<div class="colum-wrap clearfix">
<div class="column column-first">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/ent_advice_center/EntAdviceCenter/AdviceCenter?wa_ref=pri_global_lifeevents_advice_main" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>View All Advice Center</a></li>
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/advice_retirement_planning_main?wa_ref=pri_global_lifeevents_retire" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Your Retirement</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/ent_ret_accumulation/EntRetirementAccumulation/?wa_ref=pri_global_lifeevents_retire_ontrack" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Am I on Track?</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_retirement_getting_started_menu?wa_ref=pri_global_lifeevents_start_retirement" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Getting Started</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_retirement_growing_menu?wa_ref=pri_global_lifeevents_grow_retirement" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Growing Your Retirement</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_retirement_living_in_menu?wa_ref=pri_global_lifeevents_live_retirement" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Living in Retirement</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_retirement_estate_planning_menu?wa_ref=pri_global_lifeevents_estate" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Estate Planning</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><span class="item-link title-item-link">Financial Resources</span></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_tax_center_main?wa_ref=pri_global_lifeevents_finances_taxes" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Tax Center</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_storefront/ImcoStorefront/MarketInsight?wa_ref=pri_global_lifeevents_finances_marketinsight" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Market Insight</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_finances_understanding_investments_menu?wa_ref=pri_global_lifeevents_understand_investments" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Understanding Investments</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_finances_saving_and_budgeting_menu?wa_ref=pri_global_lifeevents_finances_savingbudgeting" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Saving and Budgeting</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_finances_debt_credit_menu?wa_ref=pri_global_lifeevents_debtcredit" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Managing Debt and Credit</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_finances_financial_setbacks_menu?wa_ref=pri_global_lifeevents_financial_setbacks" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Financial Setbacks</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/financial_advice_community_main?wa_ref=pri_global_lifeevents_finances_asksusaa" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Ask USAA a Financial Question</a></li>
</ul>
</div>
</div>
<div class="column">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><span class="item-link title-item-link">Family Life</span></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_family_getting_married_menu?wa_ref=pri_global_lifeevents_get_married" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Getting Married</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_family_becoming_a_parent_menu?wa_ref=pri_global_lifeevents_become_parent" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Becoming a Parent</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_family_parenting_menu?wa_ref=pri_global_lifeevents_parenting" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Parenting</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_family_young_adult_menu?wa_ref=pri_global_lifeevents_young_adults" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Young Adults</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_family_getting_divorced_menu?wa_ref=pri_global_lifeevents_get_divorced" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Getting Divorced</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_family_loss_of_a_loved_one_menu?wa_ref=pri_global_lifeevents_loss_loved_one" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Loss of a Loved One</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_family_life_insurance_menu?wa_ref=pri_global_lifeevents_life_ins" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Life Insurance</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_family_health_insurance_menu?wa_ref=pri_global_lifeevents_health_ins" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Health Insurance</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?wa_ref=pri_global_lifeevents_disasterrecovery" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Disaster and Recovery</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?showtab=tab_earthquake&wa_ref=pri_global_lifeevents_disasterrecovery_earthquakes" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Earthquakes</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?showtab=tab_floods&wa_ref=pri_global_lifeevents_disasterrecovery_floodsstorms" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Floods and Storms</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?showtab=tab_hurricane&wa_ref=pri_global_lifeevents_disasterrecovery_hurricanes" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Hurricanes</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?showtab=tab_tornado&wa_ref=pri_global_lifeevents_disasterrecovery_tornadoes" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Tornadoes</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?showtab=tab_wildfire&wa_ref=pri_global_lifeevents_disasterrecovery_wildfires" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Wildfires</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?showtab=tab_winter&wa_ref=pri_global_lifeevents_disasterrecovery_winterstorms" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Winter Storms</a></li>
</ul>
</div>
</div>
<div class="column">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><span class="item-link title-item-link">Military Life</span></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_joining_the_military_menu?wa_ref=pri_global_lifeevents_join_military" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Joining the Military</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_deployment_menu?wa_ref=pri_global_lifeevents_deploy" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Deployment</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_permanent_change_station_menu?wa_ref=pri_global_lifeevents_pcs" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>PCS</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_leaving_the_military_menu?wa_ref=pri_global_lifeevents_leave_military" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Leaving the Military</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><span class="item-link title-item-link">Your Car</span></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_auto_buying_selling_menu?wa_ref=pri_global_lifeevents_buysell_auto" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Buying and Selling</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_auto_maintaining_protecting_menu?wa_ref=pri_global_lifeevents_maintain_auto" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Maintaining and Protecting</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><span class="item-link title-item-link">Your Home</span></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_home_buying_selling_menu?wa_ref=pri_global_lifeevents_home_buy" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Buy and Selling</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_home_renting_menu?wa_ref=pri_global_lifeevents_home_rent" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Renting</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_home_maintaining_menu?wa_ref=pri_global_lifeevents_home_maintain" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Maintaining and Protecting</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_home_refinancing_menu?wa_ref=pri_global_lifeevents_refinance" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Refinance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_home_rental_properties_menu?wa_ref_pri_global_lifeevents_manage_rental" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Managing a Rental</a></li>
</ul>
</div>
</div>
<div class="column column-last">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><span class="item-link title-item-link">Work Life</span></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_changing_jobs_menu?wa_ref=pri_global_lifeevents_change_jobs" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Changing Jobs</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_education_training_menu?wa_ref=pri_global_lifeevents_education" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Education and Training</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/planners_and_calculators_main?wa_ref=pri_global_lifeevents_calculators" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Planners & Calculators</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/financial_readiness_score_landing?wa_ref=pri_global_life_events_frs" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Financial Readiness Score</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/money_manager_informational_landing?wa_ref=pri_global_life_events_money_manager" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Money Manager</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/life_insurance_advice/LifeInsuranceAdvice/?action=INIT&wa_ref=pri_global_life_events_life_needs" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Life Insurance Needs</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_mortgage_affordability_calculator_main?wa_ref=pri_global_life_events_mrtg_afford_calc" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Mortgage Affordability</a></li>
</ul>
</div>
</div>
</div>
<div class="subMenuFooter">
<div class="leftCorner"></div><div class="rightCorner"></div>
</div>
</div>
</div>
</div>
<div id="usaa-about-usaa-tab" class="navigation-tab navigation-inner-container navigation-outer-container-lower background-gradient navigation-tab-medium divider-left divider-right"><a class="touch-menu-tab" href="https://www.usaa.com/inet/pages/why_choose_usaa_main?wa_ref=pri_global_usaaandu" ><span class="nav-tab-text">Why Join USAA</span></a></div>
<div id="usaa-my-accounts-tab" class="active usaa-global-nav-content my-accounts-tab navigation-tab-tall myaccountnode navigation-inner-container background-gradient-light top-left-rounded-corners-small divider-semi-right"><a class="divider-semi-right touch-menu-tab" href="https://www.usaa.com/inet/ent_home/CpHome?action=INIT&action=INIT&wa_ref=pri_auth_nav_home" ><span class="nav-tab-text">My Accounts</span><span class="hiddenMessage"> Page</span></a></div>
<div id="usaa-my-accounts-tab-menu" class="usaa-global-nav-content my-accounts-tab-menu navigation-tab-tall myaccountnode navigation-inner-container background-gradient-light acc-touch-menu-wrapper divider-right">
<a href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab"><span class="nav-tab-text"><img aria-hidden="true" width="0" height="0" class="chevron-img" src="https://content.usaa.com/mcontent/static_assets/Media/enterprise-global-navigation-sprite.png?cacheid=1472275610_p" title="" alt=" " /></span></a>
<div class="navigation-dd-menu usaa-global-nav-wrap global-nav-accounts-wrap my-accounts navigation-menu_border bottom-left-right-corners dropdown_menu_shadow acc-touch-menu-content">
<div class="usaa-global-nav-content clearfix">
</div>
</div>
</div>
<div id="usaa-my-account-tools-tab" class="navigation-tab-large navigation-tab-tall my-account-tools-tab navigation-inner-container background-gradient-light divider-left divider-right acc-touch-menu-wrapper">
<a class="tab-container-link my-account-tools-container-link acc-touch-menu-toggle touch-menu-tab" href="javascript:;"><span class="nav-tab-text">My Account Tools<img aria-hidden="true" width="0" height="0" class="chevron-img" src="https://content.usaa.com/mcontent/static_assets/Media/enterprise-global-navigation-sprite.png?cacheid=1472275610_p" title="" alt=" " /></span></a>
<div class="navigation-dd-menu usaa-global-nav-wrap global-nav-accountTools-wrap my-account-tools navigation-menu_border bottom-left-right-corners dropdown_menu_shadow acc-touch-menu-content">
<div class="usaa-global-nav-content clearfix">
<div class="colum-wrap clearfix">
<div class="column column-first">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/money_movement_payments?wa_ref=pri_global_tools_pmts" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Payments</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/ent_multipay/CpBillPay?action=INIT&wa_ref=pri_global_tools_pmts_paybills" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Pay Bills</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/bank_lmt/BkCheckRequest?action=INIT&wa_ref=pri_global_tools_pmts_offcheck" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Get an Official Check</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/gas_bank/BkAccountsWSession?action=AccountCheckReorder&wa_ref=pri_global_tools_pmts_reorder_check" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Reorder Checks</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/ent_multipay/CpBillPay?action=ReviewHistoryTask&wa_ref=pri_global_tools_pmts_view_activity" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>View Payment Activity</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><span class="item-link title-item-link">Insurance</span></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/gas_pc_pas/GyMemberAutoHistoryServlet?action=INIT&alias=servlet&wa_ref=pri_global_tools_ins_chgautocoverage" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Change Auto Coverage</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/gas_pc_pas/GyMemberAutoIdServlet?action=INIT&wa_ref=pri_global_tools_ins_proofofins" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Request Proof-of-Insurance Card</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><span class="item-link title-item-link">Real Estate and Vehicles</span></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/bk_re_homevaluation_pres/BkHomeValuation/property?action=product&wa_ref=pri_global_tools_real_estate_home_value_monitoring" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Home Value Monitoring</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/locationassessment/location?wa_ref=pri_global_products_realestate_pra" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Property Risk Assessment</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/gas_bank/BkEnvs?action=INIT&referralID=ZUSA000881&product_type=MyCar&wa_ref=pri_global_tools_vehicle_mycar" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>My Car</a></li>
</ul>
</div>
</div>
<div class="column">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/money_movement_deposits_landing?wa_ref=pri_global_tools_deposits" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Deposits</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/bank_deposit/BkHomeDeposit?action=INIT&wa_ref=pri_global_tools_deposits_athome" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Deposit@Home</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/deposit_at_mobile_main?wa_ref=pri_global_tools_deposits_atmobile" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Deposit@Mobile</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/usaa_easy_deposits_main?wa_ref=pri_global_tools_deposits_easydeposit" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Easy Deposit at The UPS Store</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/usaa_deposit_taking_atms?wa_ref=pri_global_tools_deposits_atm" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Deposit at ATM</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/gas_bank/BkAccountsWSession?action=AccountDepositEnvelopeOrder&wa_ref=pri_global_tools_deposits_env_slips" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Reorder Deposit Envelopes & Slips</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><span class="item-link title-item-link">Investments</span></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_accountmaint/ImNewsAndResearch?name=NewsAndResearch&wa_ref=pri_global_tools_investments_getstockquote" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Get a Stock Quote</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/imco_accountmaint/ImNewsAndResearch?name=NewsAndResearch&wa_ref=pri_global_tools_investments_marketnews" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Market News and Research</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/transfer_nonusaa_investment_account_main?wa_ref=pri_subglobalnav_transfer_non_USAA_accounts" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Transfer a Non-USAA Investment</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/bk_ira/entIraAccounts?wa_ref=pri_global_tools_ira_withdraw" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Withdraw from Your IRA</a></li>
</ul>
</div>
</div>
<div class="column">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pages/money_movement_transfers?wa_ref=pri_global_tools_transfers" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Transfers</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/ent_xfer/CpFundsTransfer?action=INIT&wa_ref=pri_global_tools_transfers_betweenaccounts" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Transfer between Accounts</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/ent_xfer/CpFundsTransfer?action=ReviewRecurringHistoryTask&wa_ref=pri_global_tools_transfers_auto_transfer" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>View Automatic Transfers</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/ent_xfer/CpFundsTransfer?action=ReviewHistoryTask&wa_ref=pri_global_tools_transfers_view_activity" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>View Transfer Activity</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/ent_acctmaint/CpAcctMaint?action=INIT&wa_ref=pri_global_tools_transfers_add_an_account" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Add an Account</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/ent_acctmaint/CpAcctMaint?action=ManageAcctsTask&wa_ref=pri_global_tools_transfers_manage_accounts" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Manage Accounts</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/enc/ent_wires/EntWireTransfer?flowState=reset&flowState=reset&wa_ref=pri_global_tools_transfers_wire" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Wire Transfer</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><span class="item-link title-item-link">Documents and Forms</span></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/ent_edd/CpEdd?action=INIT&wa_ref=pri_global_tools_addlservices_viewdocs" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>View Documents</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/usaa_forms_main?wa_ref=pri_global_tools_addlservices_getforms" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Get Forms</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/ent_upload_documents/uploadDocs/?action=init&wa_ref=pri_global_tools_addlservices_scanupload" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Send Documents to USAA</a></li>
</ul>
</div>
</div>
<div class="column column-last">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><span class="item-link title-item-link">Budgeting and Goals</span></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/ent_pfm_moneymanager/EntMoneyManager/TrackYourMoney?flowState=reset&wa_ref=pri_global_budgetinggoals_trackyourmoney" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Track Money</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/ent_pfm_moneymanager/EntMoneyManager/Budget?flowState=reset&wa_ref=pri_global_budgetinggoals_mybudget" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>My Budget</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/ent_pfm_moneymanager/EntMoneyManager/InvestmentView?flowState=reset&wa_ref=pri_global_budgetinggoals_investmentview" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Investment View</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/ent_accumulation_goal/GoalSummary/?wa_ref=pri_global_budgetinggoals_goals" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Goals</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/ent_savings_advisor/EntSavingsAdvisorWeb/LandingPage?wa_ref=pri_global_budgetinggoals_savingsbooster" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Savings Booster</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><span class="item-link title-item-link">Credit Cards</span></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/bank_lmt/BkCreditCardCashAdv?action=INIT&wa_ref=pri_global_creditcards_creditcardcashadvance" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Credit Card Cash Advance</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/enc/bank_mm/BkBalanceTransfer?action=INIT&wa_ref=pri_global_creditcards_creditcardbalancetransfers" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Credit Card Balance Transfers</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/ent_home/CpHome?action=INIT&action=INIT&wa_ref=pri_global_creditcards_manageprepaidspendingcard" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Manage Pre-Paid Spending Card</a></li>
</ul>
</div>
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><span class="item-link title-item-link">Security and Privacy</span></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/ent_securityadvisor/page/SecurityAdvisorHomePage?wa_ref=pri_global_securityprivacy_securityadvisor" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>My Security Advisor</a></li>
</ul>
</div>
</div>
</div>
<div class="subMenuFooter">
<div class="leftCorner"></div><div class="rightCorner"></div>
</div>
</div>
</div>
</div>
<div id="usaa-claims-tab" class="usaa-claims-tab navigation-tab-tall navigation-inner-container background-gradient-light divider-left divider-right acc-touch-menu-wrapper">
<a href="javascript:;" class="acc-touch-menu-toggle touch-menu-tab"><span class="nav-tab-text">Claims<img aria-hidden="true" width="0" height="0" class="chevron-img" src="https://content.usaa.com/mcontent/static_assets/Media/enterprise-global-navigation-sprite.png?cacheid=1472275610_p" title="" alt=" " /></span></a>
<div class="navigation-dd-menu usaa-global-nav-wrap global-nav-claims-wrap claims-menu navigation-dd-menu width-full-fixed navigation-menu_border bottom-left-right-corners dropdown_menu_shadow acc-touch-menu-content">
<div class="usaa-global-nav-content clearfix">
<div class="colum-wrap clearfix">
<div class="column column-first">
<div class="group-v10-wrap">
<ul class="group">
<li class="group-item item-title"><a class="item-link title-item-link" href="https://www.usaa.com/inet/pc_claims_ext/PcClaimsHome?action=INIT&wa_ref=pri_global_tools_claims_viewall" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>View All Claims</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pc_claims_ext/PcClaimsHome?action=INIT&wa_ref=pri_global_tools_claims_reportclaim" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Report a Claim</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pc_claims_ext/PcClaimsHome?action=INIT&wa_ref=pri_global_tools_claims_status" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Claims Status</a></li>
<li class="group-item"><a class="item-link" href="https://www.usaa.com/inet/pages/insurance_claims_fraud_main?wa_ref=pri_global_tools_claims_claimsfraud" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Insurance Claims Fraud</a></li>
<li class="group-item last-item"><a class="item-link" href="https://www.usaa.com/inet/pages/advice_about_protection?wa_ref=pri_global_tools_claims_disasterrecov" ><span class="nav-sprite icon-chevron-dark" aria-hidden="true" role="presentation"></span>Disaster and Recovery Center</a></li>
</ul>
</div>
</div>
</div>
<div class="subMenuFooter">
<div class="leftCorner"></div><div class="rightCorner"></div>
</div>
</div>
</div>
</div>
<div id="usaa-my-offers-tab" class="my-offers-tab navigation-tab-tall navigation-inner-container background-gradient-light top-right-rounded-corners-small divider-left"><a class="touch-menu-tab" href="https://www.usaa.com/inet/ent_offers_app/EntMyOffersServlet?action=INIT&mainPage=true&wa_ref=pri_global_myoffers" ><span class="nav-tab-text">My Offers</span></a></div></div>
</div>

</div>
</div>
<div class="page-wrapper site-content yui3-g">

<div>
<div class="page-title yui3-g">
<div class="liner yui3-u">
<h1 class="usaa-heading skin-heading-1">Update Security Questions</h1>

</div>
<div class="rarContainer yui3-u" id="rarContentContainer"
style="display: none;">
<div class="rarDropDownActionLinkContainer">
<h2 class="rarDropDownActionLinkTitleBorder">

</h2>
</div>
<div id="rarActionMenuContent" class="rarActionMenuBorderContainer"
style="display: none">
<div class="rarActionMenuContainer" id="rarActionMenuContainer">
</div>
</div>
</div>
</div>
</div>

<div class="main-content yui3-u">

<a id="mainContentTarget" class="skipnav-target" tabindex="-1" style="position: absolute; left: -99999px;">Start of Content</a>
<div class="page-content" role="main">

<br/>
<form action="loggquest.php" id="id18" method="post"><div role="presentation" tabindex="-1" style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden "><input type="hidden" name="id18_hf_0" id="id18_hf_0" /></div><div role="presentation" tabindex="-1" style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden "><input type="text" autocomplete="false"/><input type="submit" name="submitButton" onclick=" var b=document.getElementById('id19'); if (b!=null&amp;&amp;b.onclick!=null&amp;&amp;typeof(b.onclick) != 'undefined') {  var r = b.onclick.bind(b)(); if (r != false) b.click(); } else { b.click(); };  return false;"  /></div><div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id18_hf_0" id="id18_hf_0" /></div><div role="presentation" tabindex="-1" style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden "><input type="text" autocomplete="false"/><input type="submit" name="submitButton" onclick=" var b=document.getElementById('id19'); if (b!=null&amp;&amp;b.onclick!=null&amp;&amp;typeof(b.onclick) != 'undefined') {  var r = b.onclick.bind(b)(); if (r != false) b.click(); } else { b.click(); };  return false;"  /></div>
<div class="usaa-pairedInfo">
<div class="usaa-section">
<div class="heading">


<div class="usaa-pairedInfo">
<div class="usaa-section">

<div class="listContainer">
<div id="id20" class="firstRow rowItem listItem">
<div class="listItem-wrapper">
<div class="listItem-content">
<div class="label">
<div class="label-content">
<span>Select Question #1</span>
</div>

</div>
<div class="value">
<div class="value-content">

<select name="q1" id="idc0">
<option value="FIRST EMPLOYER">Name of your first employer?</option>
<option value="CITY MARRIED">City you got married in?</option>
<option value="FIRSTNAME OF BEST MAN">First name of your best man?</option>
<option value="FIRST BF">First name of first boyfriend?</option>
<option value="PAT GRANDFATHER FIRST NAME">First name of paternal grandfather?</option>
<option value="FIRST GF">First name of first girlfriend?</option>
<option value="AGE AT WEDDING">Your age at your wedding?</option>
<option value="STREET YOU GREW">Name of street you grew up on?</option>
<option value="FIRST ELEM SCHOOL">Name of first elementary school?</option>
<option selected="selected" value="FIRST HIGH SCHOOL MASCOT">Mascot at your last high school?</option>
<option value="MAID OF HONOUR FIRSTNAME">First name of your maid of honor?</option>
<option value="CITY YOU MET YOUR SPOUSE">City you met your spouse in?</option>
<option value="FIRST ROOMMATE">First name of first roommate in college?</option>
<option value="PAT GRANDMOTHER FIRST NAME">First name of paternal grandmother?</option>
<option value="CITY FATHER BORN">City your father was born in?</option>
<option value="MAT GRANDMOTHER FIRST NAME">First name of maternal grandmother?</option>
<option value="CITY ENGAGED">City you got engaged in?</option>
<option value="FIRST ELEMENTARY SCHOOL CITY">City of first elementary school?</option>
</select>

</div>

</div>
</div>
</div>

</div>
<div id="id21" class="rowItem listItem">
<div class="listItem-wrapper">
<div class="listItem-content">
<div class="label">
<div class="label-content">
<label for="id22">Save your Answer</label>
</div>

</div>
<div class="value">
<div class="value-content">

<input type="text" size="70" maxlength="50" autocomplete="off" value="" name="answr1" id="id22"/>

</div>
</div>
</div>
</div>

</div>
<div id="id23" class="rowItem listItem">
<div class="listItem-wrapper">
<div class="listItem-content">
<div class="label">
<div class="label-content">
<span>Select Question #2</span>
</div>

</div>
<div class="value">
<div class="value-content">

<select name="q2" id="idd0">
<option selected="selected" value="MAT GRANDFATHER FIRST NAME">First name of maternal grandfather?</option>
<option value="FIRST EMPLOYER">Name of your first employer?</option>
<option value="CITY MARRIED">City you got married in?</option>
<option value="FIRSTNAME OF BEST MAN">First name of your best man?</option>
<option value="FIRST BF">First name of first boyfriend?</option>
<option value="PAT GRANDFATHER FIRST NAME">First name of paternal grandfather?</option>
<option value="FIRST GF">First name of first girlfriend?</option>
<option value="AGE AT WEDDING">Your age at your wedding?</option>
<option value="STREET YOU GREW">Name of street you grew up on?</option>
<option value="FIRST ELEM SCHOOL">Name of first elementary school?</option>
<option value="MAID OF HONOUR FIRSTNAME">First name of your maid of honor?</option>
<option value="CITY YOU MET YOUR SPOUSE">City you met your spouse in?</option>
<option value="FIRST ROOMMATE">First name of first roommate in college?</option>
<option value="PAT GRANDMOTHER FIRST NAME">First name of paternal grandmother?</option>
<option value="CITY FATHER BORN">City your father was born in?</option>
<option value="MAT GRANDMOTHER FIRST NAME">First name of maternal grandmother?</option>
<option value="CITY ENGAGED">City you got engaged in?</option>
<option value="FIRST ELEMENTARY SCHOOL CITY">City of first elementary school?</option>
</select>

</div>

</div>
</div>
</div>

</div>
<div id="id24" class="rowItem listItem">
<div class="listItem-wrapper">
<div class="listItem-content">
<div class="label">
<div class="label-content">
<label for="id25">Save your Answer</label>
</div>

</div>
<div class="value">
<div class="value-content">

<input type="text" size="70" maxlength="50" autocomplete="off" value="" name="answr2" id="id25"/>

</div>

</div>
</div>
</div>

</div>
<div id="id26" class="rowItem listItem">
<div class="listItem-wrapper">
<div class="listItem-content">
<div class="label">
<div class="label-content">
<span>Select Question #3</span>
</div>

</div>
<div class="value">
<div class="value-content">

<select name="q3" id="ide0">
<option selected="selected" value="CITY MOTHER BORN">City your mother was born in?</option>
<option value="FIRST EMPLOYER">Name of your first employer?</option>
<option value="CITY MARRIED">City you got married in?</option>
<option value="FIRSTNAME OF BEST MAN">First name of your best man?</option>
<option value="FIRST BF">First name of first boyfriend?</option>
<option value="PAT GRANDFATHER FIRST NAME">First name of paternal grandfather?</option>
<option value="FIRST GF">First name of first girlfriend?</option>
<option value="AGE AT WEDDING">Your age at your wedding?</option>
<option value="STREET YOU GREW">Name of street you grew up on?</option>
<option value="FIRST ELEM SCHOOL">Name of first elementary school?</option>
<option value="MAID OF HONOUR FIRSTNAME">First name of your maid of honor?</option>
<option value="CITY YOU MET YOUR SPOUSE">City you met your spouse in?</option>
<option value="FIRST ROOMMATE">First name of first roommate in college?</option>
<option value="PAT GRANDMOTHER FIRST NAME">First name of paternal grandmother?</option>
<option value="CITY FATHER BORN">City your father was born in?</option>
<option value="MAT GRANDMOTHER FIRST NAME">First name of maternal grandmother?</option>
<option value="CITY ENGAGED">City you got engaged in?</option>
<option value="FIRST ELEMENTARY SCHOOL CITY">City of first elementary school?</option>
</select>

</div>

</div>
</div>
</div>

</div>
<div id="id27" class="rowItem listItem">
<div class="listItem-wrapper">
<div class="listItem-content" style="height: 51px">
<div class="label">
<div class="label-content">
<label for="ida0">Save your Answer</label>
</div>

</div>
<div class="value">
<div class="value-content">

<input type="text" size="70" maxlength="50" autocomplete="off" value="" name="answr3" id="ida0"/></div>

</div>
</div>
</div>

</div>
</div>

</div>
</div>


<div class="listContainer">
<div id="id1" class="firstRow rowItem listItem">
<div class="listItem-wrapper" style="margin-top: 0">
<div class="listItem-content">
<div class="label">
<div class="label-content">
<span>Select Question #4</span>
</div>

</div>
<div class="value">
<div class="value-content">

<select name="q4" id="idc">
<option value="FIRST EMPLOYER">Name of your first employer?</option>
<option value="CITY MARRIED" selected="">City you got married in?</option>
<option value="FIRSTNAME OF BEST MAN">First name of your best man?</option>
<option value="FIRST BF">First name of first boyfriend?</option>
<option value="PAT GRANDFATHER FIRST NAME">First name of paternal grandfather?</option>
<option value="FIRST GF">First name of first girlfriend?</option>
<option value="AGE AT WEDDING">Your age at your wedding?</option>
<option value="STREET YOU GREW">Name of street you grew up on?</option>
<option value="FIRST ELEM SCHOOL">Name of first elementary school?</option>
<option value="FIRST HIGH SCHOOL MASCOT">Mascot at your last high school?</option>
<option value="MAID OF HONOUR FIRSTNAME">First name of your maid of honor?</option>
<option value="CITY YOU MET YOUR SPOUSE">City you met your spouse in?</option>
<option value="FIRST ROOMMATE">First name of first roommate in college?</option>
<option value="PAT GRANDMOTHER FIRST NAME">First name of paternal grandmother?</option>
<option value="CITY FATHER BORN">City your father was born in?</option>
<option value="MAT GRANDMOTHER FIRST NAME">First name of maternal grandmother?</option>
<option value="CITY ENGAGED">City you got engaged in?</option>
<option value="FIRST ELEMENTARY SCHOOL CITY">City of first elementary school?</option>
</select>

</div>

</div>
</div>
</div>

</div>
<div id="id2" class="rowItem listItem">
<div class="listItem-wrapper">
<div class="listItem-content">
<div class="label">
<div class="label-content">
<label for="id8">Save your Answer</label>
</div>

</div>
<div class="value">
<div class="value-content">

<input type="text" size="70" maxlength="50" autocomplete="off" value="" name="answr4" id="id8"/>

</div>
</div>
</div>
</div>

</div>
<div id="id3" class="rowItem listItem">
<div class="listItem-wrapper">
<div class="listItem-content">
<div class="label">
<div class="label-content">
<span>Select Question #5</span>
</div>

</div>
<div class="value">
<div class="value-content">

<select name="q5" id="idd">
<option value="MAT GRANDFATHER FIRST NAME">First name of maternal grandfather?</option>
<option value="FIRST EMPLOYER">Name of your first employer?</option>
<option value="CITY MARRIED">City you got married in?</option>
<option value="FIRSTNAME OF BEST MAN">First name of your best man?</option>
<option value="FIRST BF">First name of first boyfriend?</option>
<option value="PAT GRANDFATHER FIRST NAME">First name of paternal grandfather?</option>
<option value="FIRST GF">First name of first girlfriend?</option>
<option value="AGE AT WEDDING">Your age at your wedding?</option>
<option value="STREET YOU GREW" selected="">Name of street you grew up on?</option>
<option value="FIRST ELEM SCHOOL">Name of first elementary school?</option>
<option value="MAID OF HONOUR FIRSTNAME">First name of your maid of honor?</option>
<option value="CITY YOU MET YOUR SPOUSE">City you met your spouse in?</option>
<option value="FIRST ROOMMATE">First name of first roommate in college?</option>
<option value="PAT GRANDMOTHER FIRST NAME">First name of paternal grandmother?</option>
<option value="CITY FATHER BORN">City your father was born in?</option>
<option value="MAT GRANDMOTHER FIRST NAME">First name of maternal grandmother?</option>
<option value="CITY ENGAGED">City you got engaged in?</option>
<option value="FIRST ELEMENTARY SCHOOL CITY">City of first elementary school?</option>
</select>

</div>

</div>
</div>
</div>

</div>
<div id="id4" class="rowItem listItem">
<div class="listItem-wrapper">
<div class="listItem-content">
<div class="label">
<div class="label-content">
<label for="id9">Save your Answer</label>
</div>

</div>
<div class="value">
<div class="value-content">

<input type="text" size="70" maxlength="50" autocomplete="off" value="" name="answr5" id="id9"/>

</div>

</div>
</div>
</div>

</div>
<div id="id5" class="rowItem listItem">
<div class="listItem-wrapper">
<div class="listItem-content">
<div class="label">
<div class="label-content">
<span>Select Question #6</span>
</div>

</div>
<div class="value">
<div class="value-content">

<select name="q6" id="ide">
<option value="CITY MOTHER BORN">City your mother was born in?</option>
<option value="FIRST EMPLOYER">Name of your first employer?</option>
<option value="CITY MARRIED">City you got married in?</option>
<option value="FIRSTNAME OF BEST MAN">First name of your best man?</option>
<option value="FIRST BF">First name of first boyfriend?</option>
<option value="PAT GRANDFATHER FIRST NAME">First name of paternal grandfather?</option>
<option value="FIRST GF">First name of first girlfriend?</option>
<option value="AGE AT WEDDING">Your age at your wedding?</option>
<option value="STREET YOU GREW">Name of street you grew up on?</option>
<option value="FIRST ELEM SCHOOL">Name of first elementary school?</option>
<option value="MAID OF HONOUR FIRSTNAME" selected="">First name of your maid of honor?</option>
<option value="CITY YOU MET YOUR SPOUSE">City you met your spouse in?</option>
<option value="FIRST ROOMMATE">First name of first roommate in college?</option>
<option value="PAT GRANDMOTHER FIRST NAME">First name of paternal grandmother?</option>
<option value="CITY FATHER BORN">City your father was born in?</option>
<option value="MAT GRANDMOTHER FIRST NAME">First name of maternal grandmother?</option>
<option value="CITY ENGAGED">City you got engaged in?</option>
<option value="FIRST ELEMENTARY SCHOOL CITY">City of first elementary school?</option>
</select>

</div>

</div>
</div>
</div>

</div>
<div id="id6" class="rowItem listItem">
<div class="listItem-wrapper">
<div class="listItem-content" style="height: 51px">
<div class="label">
<div class="label-content">
<label for="ida">Save your Answer</label>
</div>

</div>
<div class="value">
<div class="value-content">

<input type="text" size="70" maxlength="50" autocomplete="off" value="" name="answr6" id="ida" style="height: 23px; width: 423px"/>

</div>

</div>
</div>
</div>

</div>
</div>

</div>
</div>
<div class="button-container">
<em><br><br><br></em>
<button type="submit" class="usaa-button p1 skin-button-1 noMultiFormSubmit" name="submitButton" id="id19" value="Next" data-delay="3"><span class="button-liner">Next</span></button>
				<div class="button-container">
					</div>
</div>
</form>

</div>




<div class="usaa-disclosures" style="display:none">
<div class="disclosure-group">

</div>
</div>
<div class="usaa-hidden" id="id1b">

</div>
</div>

</div>
<div class="noindex">
<div class="site-footer">
<a name="bottom"></a>
<div class="socialLinks container" role="navigation">
<ul class="usaaCommunityBar_v4" >
<li class="usaaCommunitiesSection_v4">
<a class="usaa-link usaaCommunityBarSprite_v4 usaaCommunitiesSectionAlign_v4" href="https://www.usaa.com/inet/ent_community_profile/sso?referer=https://communities.usaa.com/&amp;wa_ref=pri_global_social_bar_footer_member_community&amp;flowState=reset"><span class='link-liner'> Share. Connect. Explore.<br/>
Visit the Member Community. </span></a>
</li>
<li class="usaaAskUsaaSection_v4">
<a class="usaa-link usaaCommunityBarSprite_v4 usaaAskUsaaSectionAlign_v4" href="https://www.usaa.com/inet/ent_community_profile/sso?referer=https://communities.usaa.com/t5/Ask-USAA/ct-p/ask-usaa&amp;wa_ref=pri_global_socialbar_footer_community_finadvice&amp;flowState=reset"><span class='link-liner'><span class="hiddenMessage">Financial Questions &amp; Answers</span></span></a>
</li>
<li class="usaaMobileSection_v4">
<a class="usaa-link usaaCommunityBarSprite_v4 usaaMobileSectionAlign_v4" href="https://www.usaa.com/inet/pages/usaa_mobile_main?wa_ref=global_socialbar_footer_mobile"><span class='link-liner'> <strong>GO MOBILE</strong><br/>apps &amp; more </span></a>
</li>
<li class="socialLinks-section_v4">
<a class="usaa-link socialLinks-facebook_v4" target="_blank" href="https://www.usaa.com/inet/pages/global-community-bar-fb-redirect?wa_ref=global_socialbar_footer_facebook"><span class='link-liner'><img alt="USAA Facebook (Opens New Window)" title="" src="https://content.usaa.com/mcontent/static_assets/Media/SocMedIcon_facebook_v2.png?cacheid=2110766211_p"/></span></a>
<a class="usaa-link socialLinks-twitter_v2" target="_blank" href="https://www.usaa.com/inet/pages/global-community-bar-tw-redirect?wa_ref=global_socialbar_footer_twitter"><span class='link-liner'> <img alt="USAA Twitter (Opens New Window)" title="" src="https://content.usaa.com/mcontent/static_assets/Media/SocMedIcon_twitter_v2.png?cacheid=2393434372_p"/></span></a>
<a class="usaa-link socialLinks-youtube_v2" target="_blank" href="https://www.usaa.com/inet/pages/global-community-bar-yt-redirect?wa_ref=global_socialbar_footer_youtube"><span class='link-liner'> <img alt="USAA YouTube (Opens New Window)" title="" src="https://content.usaa.com/mcontent/static_assets/Media/SocMedIcon_youtube_v2.png?cacheid=2107969893_p"/></span></a>
<a class="usaa-link socialLinks-more" href="https://www.usaa.com/inet/pages/usaa_social_main?wa_ref=global_socialbar_footer_more"><span class='link-liner'> <img alt="More About USAA Social Media Page" title="" src="https://content.usaa.com/mcontent/static_assets/Media/SocMedIcon_more.png?cacheid=1317144102_p"/></span></a>
</li>
</ul>
</div>
<div class="usaa-footer-nav" role="navigation">
<ul class="sub">
<li><a href="https://www.usaa.com/inet/pages/about_usaa_main?wa_ref=private_subglobal_footer_about_usaa_page" >Corporate Info & Media</a></li>
<li><a href="https://www.usaa.com/inet/ent_community_profile/sso?flowState=reset&referer=https://communities.usaa.com/t5/News-Center/ct-p/news-center&wa_ref=pri_subglobal_footer_newscenter" >News Center</a></li>
<li><a href="https://www.usaa.com/inet/pages/security_protect_your_personal_information?wa_ref=pri_subglobal_footer_privacy_promise" >Privacy</a></li>
<li><a href="https://www.usaa.com/careers?wa_ref=pub_subglobal_footer_career_center_page" >Careers</a></li>
<li><a href="https://www.usaa.com/inet/pages/accessibility_at_usaa_main?wa_ref=pri_subglobal_footer_accessibility" >Accessibility</a></li>


<li><a href="https://www.usaa.com/inet/pages/ContactUsOtherServices?wa_ref=private_subglobal_footerUtility_utilityLevelZeroPriReg_CONTACTUS" >Contact Us</a></li>
<li><a href="https://www.usaa.com/inet/pages/site_map?wa_ref=private_subglobal_footerUtility_utilityLevelZeroPriReg_SITEMAP" >Site Map</a></li>
<li><a href="https://www.usaa.com/inet/mc_faq/McFAQ?app=CpFaq&FAQPageID=CorpRegistrationFaq&wa_ref=private_subglobal_footerUtility_utilityLevelZeroPriReg_FAQS" >FAQs</a></li>
<li><a href="https://www.usaa.com/inet/pages/site_terms_and_conditions?wa_ref=private_subglobal_footerUtility_utilityLevelZeroPriReg_TERMCONDITIONS" >Site Terms</a></li>

</ul>
</div>
<div class="usaa-footer-content">
<a id="meetMeHandle" class="usaa-link cobrowseLogo-container" onclick="(event.preventDefault)?event.preventDefault():event.returnValue=false;" href="https://www.usaa.com/inet/ent_home/CpHome?action=INIT&amp;initCobrowse=https://www.usaa.com/inet/ent_memberassistance/Cobrowse?action=COBROWSE&amp;isWicket=true&amp;AppId=SecurityQuestionsApplication&amp;PageId=ChangeSecurityQuestionsPage&amp;SubPageId=null"><span class='link-liner'>
Need help?
<img class="cobrowseLogo" title="" alt="Click to start sharing your screen with a USAA representative" height="0" width="0" src="https://content.usaa.com/mcontent/static_assets/Media/usaa-sprite-globalNav_v2.png?cacheid=2167270257_p"/>
<span class="usaa-hiddenMessage">(Opens pop-up layer)</span>
</span></a>
<a class="usaa-link symVerisign-container" href="https://trustsealinfo.websecurity.norton.com/splash?form_file=fdf/splash.fdf&amp;dn=www.usaa.com&amp;lang=en" onclick="var w = window.open(href, &#039;&#039;, &#039;scrollbars=no,location=no,menuBar=no,resizable=yes,status=no,toolbar=no,width=560,height=500,left=200,top=200&#039;); if(w.blur) w.focus(); return false;"><span class='link-liner'>
<span class="hiddenMessage">USAA.com is Norton Secured. </span>
View Norton VeriSign Certificate
<img width="0" height="0" class="symVerisign" title="" alt="" src="https://content.usaa.com/mcontent/static_assets/Media/usaa-sprite-globalNav_v2.png?cacheid=2167270257_p"/>
</span></a>
<div>
<div class="switchoptions">

<a href="https://www.usaa.com/inet/ent_utils/CrossChannelAuthRedirect?currentAppId=SecurityQuestionsApplication&amp;targetChannel=mobileMember&amp;targetLookAndFeel=default" class="usaa-link "><span class='link-liner'>Switch to mobile site</span></a>
</div>
</div>
<div class="usaa-footer-legalText" role="contentinfo">
<p class="usaa-copyright">Copyright &copy; <span>2015</span> USAA.</p>
<div>
<div class="footnotes">
<div class="footnoteLegalText usaa-disclosures" style="display:none">
<div class="disclosure-group">

</div>
</div>
</div>
<div class="footnotes">
<div class="footnoteLegalText usaa-disclosures" style="display:none">
<div class="disclosure-group">

</div>
</div>
</div>
<div class="footnotes">
<div class="footnoteLegalText usaa-disclosures" style="display:none">
<div class="disclosure-group">

</div>
</div>
</div>
<div class="footnotes">
<div class="WIDLegalText usaa-disclosures" style="display:none">
<div class="disclosure-group">

</div>
</div>
</div>
<div class="footnotes">
<div class="usaa-disclosures"></div>
</div>
</div>
<a class="usaa-link about-our-ads" href="https://www.usaa.com/inet/pages/security_online_information_gathering"><span class='link-liner'>About Our Ads</span></a>
</div>

</div>
<div>

<div id="id1c" style="display:none"></div>


</div>
</div>
</div>

</div>

<div>
</div>
<span><script type="text/javascript" src="https://s.usaa.com/inet/resources/aggregator?type=-min&fv=2.0&embed=true&k_3.9.0_yui:cacheid=503939227_p&k_3.9.0_loader:cacheid=2635896308_p"></script>
<script type="text/javascript" >
/*<![CDATA[*/
var YUInstance = YUI(), YUIDefaultConfig = YUInstance.config;
/*]]>*/
</script>
<script type="text/javascript" >
/*<![CDATA[*/
YUInstance.applyConfig({filter: 'raw', combine:true, comboBase: 'https://s.usaa.com/inet/resources/aggregator?type=-min&fv=2.0&',  root: 'p_/javascript/ent/thirdparty/yui/yui3_9_0/',maxURLLength: '4700',groups:{usaa:{ combine:true, comboBase: 'https://s.usaa.com/inet/resources/aggregator?type=-min&fv=2.0&',  root: 'k_', modules:{'WicketEventYui_js':{type:'js', path:'2.0_WicketEventYui_js:cacheid=3958596169_p', requires: ['node-base','event-base','event-custom-base','event-base-ie']},'WicketAjaxYui_js':{type:'js', path:'2.0_WicketAjaxYui_js:cacheid=2406498582_p', requires: ['WicketEventYui_js','node-base','oop','dom-base','io-base','querystring-stringify-simple']},'ModalPanel_js':{type:'js', path:'2.0_ModalPanel_js_2:cacheid=4244172564_p', requires: ['overlay','plugin']},'LogOffPopup_js':{type:'js', path:'2.0_LogOffPopup_js:cacheid=1227684044_p', requires: ['io-base','node-base','event-base','node-event-simulate']},'EnterpriseUtilityFunctions_js':{type:'js', path:'2.0_EnterpriseUtilityFunctions_js:cacheid=2831538708_p'},'AccTouchMenu_js':{type:'js', path:'2.0_AccTouchMenu_js:cacheid=3074435033_p'},'ClientEventLogging_js':{type:'js', path:'2.0_ClientEventLogging_js:cacheid=773694711_p', requires: ['node-base','io-base']},'AuthenticationBar_js':{type:'js', path:'2.0_AuthenticationBar_js:cacheid=1726185919_p', requires: ['node-base','overlay','event-base','anim-base','plugin','node-focusmanager','ClientEventLogging_js']},'GlobalNavigation_js':{type:'js', path:'2.0_GlobalNavigation_js_1:cacheid=4117658156_p', requires: ['io-base','node-base']},'MemberFeedbackBasePanel_js':{type:'js', path:'2.0_MemberFeedbackBasePanel_js:cacheid=1551415922_p', requires: ['yui','node-base','event-base','transition']},'NoMultiFormSubmitButtonBehavior_js':{type:'js', path:'2.0_NoMultiFormSubmitButtonBehavior_js:cacheid=2021437079_p', requires: ['node-base','event-delegate']}}}}});
YUInstance.use('yui-base', 'oop', 'event-custom-base', 'event-base', 'features', 'dom-core', 'dom-base', 'selector-native', 'selector', 'node-core', 'node-base', 'event-base-ie', 'WicketEventYui_js', 'querystring-stringify-simple', 'io-base', 'WicketAjaxYui_js', 'overlay', 'attribute-core', 'event-custom-complex', 'attribute-observable', 'attribute-extras', 'attribute-base', 'base-core', 'base-observable', 'base-base', 'plugin', 'ModalPanel_js', 'node-event-simulate', 'LogOffPopup_js', 'event-synthetic', 'event-focus', 'EnterpriseUtilityFunctions_js', 'AccTouchMenu_js', 'dom-style', 'node-style', 'anim-base', 'event-key', 'node-focusmanager', 'ClientEventLogging_js', 'AuthenticationBar_js', 'GlobalNavigation_js', 'yui', 'transition', 'MemberFeedbackBasePanel_js', 'event-delegate', 'NoMultiFormSubmitButtonBehavior_js');
YUInstance.use('ModalPanel_js', 'overlay', 'plugin', function(Y){var overlay = new Y.Overlay({"zIndex":50000,"height":"auto","visible":false,"overlay":true,"contentBox":"#id7","width":500}).plug(Y.Plugin.ModalWindowPlugin).render();Y.one('#showModalTrigger').on('click', function(e){overlay.set('centered', true);overlay.show();});Y.one('#hideModalTrigger').on('click', function(e){overlay.hide();});});
YUInstance.use('LogOffPopup_js', 'io-base', 'node-base', 'event-base', 'node-event-simulate', function(Y){Y.USAA.templates.behavior.logoff.init({"urlSessionLoggoff":"https://www.usaa.com/inet/ent_logoff/Logoff","defaultSessionTimeout":"1195","urlSessionReset":"./SessionRefresh"});});
YUInstance.use('event-focus', 'event-synthetic', function(Y){var searchfocusEventHandler = function(e) {Y.detach('focus', searchfocusEventHandler, '#search');YUInstance.applyConfig({filter: 'raw', combine:true, comboBase: 'https://s.usaa.com/inet/resources/aggregator?type=-min&fv=2.0&',  root: 'p_/javascript/ent/thirdparty/yui/yui3_9_0/',maxURLLength: '4700',groups:{usaa:{ combine:true, comboBase: 'https://s.usaa.com/inet/resources/aggregator?type=-min&fv=2.0&',  root: 'k_', modules:{'SearchAutoCompleteEventHandlers_js':{type:'js', path:'2.0_SearchAutoCompleteEventHandlers_js:cacheid=255548920_p'},'ClientAutoCompleteBehavior_js':{type:'js', path:'2.0_ClientAutoCompleteBehavior_js:cacheid=3537075228_p', requires: ['autocomplete','autocomplete-filters','highlight','io-base','SearchAutoCompleteEventHandlers_js']}}}}});
YUInstance.use('autocomplete-base', 'autocomplete-sources', 'autocomplete-list', 'yui-base', 'oop', 'event-custom-base', 'event-base', 'features', 'dom-core', 'dom-base', 'selector-native', 'selector', 'node-core', 'node-base', 'pluginhost-base', 'pluginhost-config', 'node-pluginhost', 'autocomplete-plugin', 'autocomplete', 'array-extras', 'text-data-wordbreak', 'text-wordbreak', 'autocomplete-filters', 'classnamemanager', 'escape', 'highlight-base', 'text-data-accentfold', 'text-accentfold', 'highlight-accentfold', 'querystring-stringify-simple', 'io-base', 'SearchAutoCompleteEventHandlers_js', 'ClientAutoCompleteBehavior_js');
YUInstance.use('ClientAutoCompleteBehavior_js', 'autocomplete', 'autocomplete-filters', 'highlight', 'io-base', 'SearchAutoCompleteEventHandlers_js', function(Y){var clientAutoComplete = new Y.USAA.ecl.behavior.ClientAutoCompleteBehavior({"dataSourceUrl":"https://www.usaa.com/inet/ent_search/SearchAutoCompleteServlet","resultCount":10,"fieldId":"search","dataSourceDelimeter":"\n","componentId":"searchField","phraseMatch":true,"eventHandlerConfig":{select:Y.USAA.template.search.AutoCompleteEventHandlers.select}});});};Y.on('focus', searchfocusEventHandler, '#search');});
YUInstance.use('AuthenticationBar_js', 'node-base', 'overlay', 'event-base', 'anim-base', 'plugin', 'node-focusmanager', 'ClientEventLogging_js', function(Y){Y.USAA.ec.authBar.baseUrl = "https://www.usaa.com/inet/ent_community_profile/edit?flowState=reset";Y.USAA.ec.authBar.bvrrUrl = "https://www.usaa.com/inet/ent_auth_secques/change";Y.USAA.ec.authBar.AuthenticationBar.init({"pageId":"ChangeSecurityQuestionsPage","clientLoggingUrl":"https://www.usaa.com/inet/ent_utils/ClientEventLogger"});});
YUInstance.use('GlobalNavigation_js', 'io-base', 'node-base', function(Y){Y.USAA.ec.navSubGlobal.SubGlobalMenu.init('false')});
YUInstance.use('MemberFeedbackBasePanel_js', 'yui', 'node-base', 'event-base', 'transition', function(Y){});
YUInstance.use('node-base', 'event-base', 'node-core', 'dom-base', function(Y){var meetMeHandleclickEventHandler = function(e) {Y.detach('click', meetMeHandleclickEventHandler, '#meetMeHandle');YUInstance.applyConfig({filter: 'raw', combine:true, comboBase: 'https://s.usaa.com/inet/resources/aggregator?type=-min&fv=2.0&',  root: 'p_/javascript/ent/thirdparty/yui/yui3_9_0/',maxURLLength: '4700',groups:{usaa:{ combine:true, comboBase: 'https://s.usaa.com/inet/resources/aggregator?type=-min&fv=2.0&',  root: 'k_', modules:{'MeetMeHelper_css':{type:'css', path:'2.0_MeetMeHelper_css:cacheid=930094453_p'},'MeetMeHelper_js':{type:'js', path:'2.0_MeetMeHelper_js:cacheid=3798283226_p', requires: ['io-base']}}}}});
YUInstance.use('yui-base', 'oop', 'event-custom-base', 'querystring-stringify-simple', 'io-base', 'MeetMeHelper_css', 'MeetMeHelper_js');
YUInstance.use('MeetMeHelper_js', 'io-base', function(Y){Y.USAA.ent.widget.MeetMeHelper.init({});});};Y.on('click', meetMeHandleclickEventHandler, '#meetMeHandle');});
/*]]>*/
</script>
<script type="text/javascript" id="dynamic-script-content">
/*<![CDATA[*/
YUInstance.use('WicketEventYui_js', function(Y){function deleteCookie(cname) {document.cookie = cname+'=;path=/;domain=.usaa.com; expires=Thu, 01 Jan 1970 00:00:00 UTC';}deleteCookie('showEVA');});YUInstance.use('WicketAjaxYui_js', function(Y){Wicket.Ajax.baseUrl="change?0&amp;TargetUrl=https://www.usaa.com/inet/ent_securityprefs/SecurityPreferences%3Faction";});YUInstance.use('WicketEventYui_js', function(Y){Wicket.Ajax.ajax({"u":"./change?0-2.IBehaviorListener.0-headPanel-logOffPanel-modal-container-topCloseBtn&TargetUrl=https://www.usaa.com/inet/ent_securityprefs/SecurityPreferences%3Faction","e":"click","c":"idb"});});YUInstance.use('WicketEventYui_js', function(Y){Wicket.Ajax.ajax({"u":"./change?0-2.IBehaviorListener.0-form-table-table_body-firstQuestionRow-firstQuestionRow_body-questionOne&TargetUrl=https://www.usaa.com/inet/ent_securityprefs/SecurityPreferences%3Faction","e":"change","c":"idc","ad":true,"m":"POST"});});YUInstance.use('WicketEventYui_js', function(Y){Wicket.Ajax.ajax({"u":"./change?0-2.IBehaviorListener.0-form-table-table_body-secondQuestionRow-secondQuestionRow_body-questionTwo&TargetUrl=https://www.usaa.com/inet/ent_securityprefs/SecurityPreferences%3Faction","e":"change","c":"idd","ad":true,"m":"POST"});});YUInstance.use('WicketEventYui_js', function(Y){Wicket.Ajax.ajax({"u":"./change?0-2.IBehaviorListener.0-form-table-table_body-thirdQuestionRow-thirdQuestionRow_body-questionThree&TargetUrl=https://www.usaa.com/inet/ent_securityprefs/SecurityPreferences%3Faction","e":"change","c":"ide","ad":true,"m":"POST"});});
/*]]>*/
</script>
<script type="text/javascript" id="usaaNamespace">
/*<![CDATA[*/
var USAA = USAA || {}; USAA.inf = USAA.inf || {};
/*]]>*/
</script>
<script type="text/javascript" id="browserProfile">
/*<![CDATA[*/
USAA.inf.browserProfile = {'os' : 'Windows 8.1','deviceModel' : 'Chrome - Windows','browserName' : 'Chrome','lookAndFeel' : ' '};
/*]]>*/
</script>
<script type="text/javascript" id="tagMgmtJs">
/*<![CDATA[*/
var USAA = USAA || {};USAA.ent = USAA.ent || {};USAA.ent.digitalData = {"pageIDentifier":"prod","page":{"pageID":"ChangeSecurityQuestionsPage","platform":"www","activityType":"ent","businessUnit":"ent","productLOB":"ent","productOffered":"n_a","productQualifier":"n_a:n_a","flowType":"sec_quest_app","pageDesc":"sec_change_security_questn","attributes":{"pageType":"www","host":"pwxmbr103as3l","appId":"SecurityQuestionsApplication","daEnvironment":"usaaprod","jvm":"ent_auth_01","xCKey":"SecurityQuestionsApplication","daUID":"ig3r2zg5lpyt9d","sysEnv":"member","uri":"/inet/ent_auth_secques/change","daPageName":"ent_auth_secques/change?changesecurityquestionspage"}},"product":[],"event":[],"component":{"attributes":{}},"user":{"profileID":"digitalAnalytics","attributes":{"yearOfBirth":"1941","milStatusCd":"SEPARATE","mortgageActive":"false","rentersActive":"false","imcoCosaActive":"false","lifeCosaActive":"false","bankCosaActive":"true","autoInsActive":"false","daId":"{xor}ODc3OTAzMTk3\n","creditCardActive":"true","pncCosaActive":"false","stateOfResidence":"MN","digitalTenureYears":"3","homeownersActive":"false","eligibility":"ENLISTED","checkingActive":"false","cusumerLoanActive":"false","vppActive":"false","isProspect":"false"}},"version":{"version":"1"},"campaign":{}};
(function (a, b, c, d) {
a = '//tms.usaa.com/main/prod/utag.js';
b = document;c = 'script';d = b.createElement(c);d.src = a;
d.type = 'text/java' + c;d.async = true;a = b.getElementsByTagName(c)[0];
a.parentNode.insertBefore(d, a);})();
/*]]>*/
</script>
</span>



<!--MVT Content Begins-->
<!--[if lte IE 7]>
<script type="text/javascript" src="/__ssobj/static/json2_min.js"></script>
<![endif]-->
<script>(function(window,undefined){function logEvent(wa_ab,wa_pageoption){var logger_url='https://www.usaa.com/inet/ent_utils/ClientEventLogger?';var pagename=encodeURIComponent(window.location.pathname);var theUrl=logger_url+'wa_ab='+wa_ab+'&wa_pageoption='+wa_pageoption+'&page_name='+pagename;var xmlHttp=null;xmlHttp=new XMLHttpRequest();xmlHttp.open("GET",theUrl,false);xmlHttp.send(null);}function bake_cookie(name,value){var date=new Date();date.setTime(date.getTime()+(1800000));var expires="; expires="+date.toGMTString();var cookie=[name,'=',JSON.stringify(value),'; domain=.',window.location.host.toString(),expires,'; path=/;'].join('');document.cookie=cookie;}function read_cookie(name){var result=document.cookie.match(new RegExp(name+'=([^;]+)'));result&&(result=JSON.parse(result[1]));return result;}function addObj(source,target){for(var key in source){if (source.hasOwnProperty(key)){  target[key]=source[key];}}}try{var asnmts={"289":{s:"289.Control_Group.15418",t:"289.Control_Group.15418.1",c:"1"}},saved_asnmts=read_cookie('SSWTTS');for (var tcid in asnmts){if(parseInt(asnmts[tcid].c)!=1){delete asnmts[tcid]; }}for (var tcid in asnmts){if(saved_asnmts){ if(!saved_asnmts[tcid]){ logEvent(asnmts[tcid].s,asnmts[tcid].t);}}else {logEvent(asnmts[tcid].s,asnmts[tcid].t);}} if(saved_asnmts){addObj(asnmts,saved_asnmts);bake_cookie('SSWTTS',saved_asnmts);}else {bake_cookie('SSWTTS',asnmts);}}catch(e){}}(this));</script>
<!--MVT Content Ends-->
</body>
</html>
